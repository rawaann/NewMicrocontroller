
public class Instruction {
	public String address;
	public int stage;
	
	public Instruction(String address) {
		this.address = address;
		this.stage = 1;
	}
}
